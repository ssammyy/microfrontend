export interface ApiResponse {
  payload: any;
  response: string;
  status: number;
}
