export class Titles {
    id: number;
    title: string;
    remarks: string;
    status: string;
}
