export interface Town {
  id: number;
  countyId: number;
  town: string;
  status: boolean;
}
