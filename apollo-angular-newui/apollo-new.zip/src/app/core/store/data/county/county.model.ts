export interface County {
  id: number;
  regionId: number;
  county: string;
  status: boolean;
}
