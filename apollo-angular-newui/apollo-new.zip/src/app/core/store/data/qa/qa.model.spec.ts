import {Qa} from './qa.model';

describe('Qa', () => {
    it('should create an instance', () => {
        expect(new Qa()).toBeTruthy();
    });
});
