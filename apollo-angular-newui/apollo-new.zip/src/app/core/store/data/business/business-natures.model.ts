export interface BusinessNatures {
  id: number;
  businessLinesId: number;
  name: string;
  descriptions: string;
  status: boolean;
}
