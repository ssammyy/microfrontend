export interface BusinessLines {
  id: number;
  name: string;
  descriptions: string;
  status: boolean;
}
