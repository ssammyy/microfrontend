import { EntityMetadataMap, EntityDataModuleConfig } from '@ngrx/data';

const entityMetadata: EntityMetadataMap = {};

const pluralNames = {  };
/**
 * TODO: Discuss as it seems to kill sending of requests to backend
 */
// export const entityConfig: EntityDataModuleConfig = {
//   entityMetadata,
//   pluralNames
// };
