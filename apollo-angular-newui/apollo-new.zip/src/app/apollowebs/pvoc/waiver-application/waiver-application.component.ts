import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-waiver-application',
  templateUrl: './waiver-application.component.html',
  styleUrls: ['./waiver-application.component.css']
})
export class WaiverApplicationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
