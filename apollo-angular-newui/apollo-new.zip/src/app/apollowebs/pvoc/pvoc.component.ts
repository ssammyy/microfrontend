import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pvoc',
  templateUrl: './pvoc.component.html',
  styleUrls: ['./pvoc.component.css']
})
export class PVOCComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
