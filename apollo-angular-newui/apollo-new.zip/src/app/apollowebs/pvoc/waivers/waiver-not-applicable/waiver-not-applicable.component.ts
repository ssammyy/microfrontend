import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-waiver-not-applicable',
  templateUrl: './waiver-not-applicable.component.html',
  styleUrls: ['./waiver-not-applicable.component.css']
})
export class WaiverNotApplicableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
