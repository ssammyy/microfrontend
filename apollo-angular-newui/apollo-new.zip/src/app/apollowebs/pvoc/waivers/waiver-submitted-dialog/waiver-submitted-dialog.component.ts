import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-waiver-submitted-dialog',
  templateUrl: './waiver-submitted-dialog.component.html',
  styleUrls: ['./waiver-submitted-dialog.component.css']
})
export class WaiverSubmittedDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
