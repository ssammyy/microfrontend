import { PasswordValidation } from './password-validation';

describe('PasswordValidation', () => {
  it('should create an instance', () => {
    expect(new PasswordValidation()).toBeTruthy();
  });
});
