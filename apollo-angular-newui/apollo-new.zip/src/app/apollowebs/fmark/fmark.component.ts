import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fmark',
  templateUrl: './fmark.component.html',
  styleUrls: ['./fmark.component.css']
})
export class FmarkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
